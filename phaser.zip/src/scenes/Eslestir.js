export class Eslestir extends Phaser.Scene {
    constructor() {
        super('Eslestir');
    }

    init() {
        this.slots = [];
        
        this.questions = [
            { text1: "Ercan ", text2: " olduğunu söyledi.", answer: "Ankaralı", y: 0.25 },
            { text1: "Babam Boğaziçi ", text2: " mezun olmuş.", answer: "Üniversitesi'nden", y: 0.40 },
            { text1: "Veteriner, ", text2: " aşılarını yaptı.", answer: "Köpeğimin", y: 0.55 }
        ];
    }

    preload() {

    }

    create() {
        this.startTime  = Date.now();
        const { width, height } = this.cameras.main;
        
        // Arka Plan
        this.cameras.main.setBackgroundColor('#E3F2FD');
        let bg = this.add.image(width / 2, height / 2, 'Dogru_yanlis_oyunu_plan').setDepth(-1);
        bg.setDisplaySize(width, height); 
        
        this.questions.forEach(q => {
            const yazi = this.createSlot(width / 8, height * q.y, q.text1, q.text2, q.answer);
        });

        // 3. Sürüklenebilir Kartlar
        const options = ["Ankara'lı", "Ankaralı", "Üniversitesinden", "Üniversitesi'nden", "Köpeğim'in", "Köpeğimin"];
        Phaser.Utils.Array.Shuffle(options);

        this.Eslestirme_oyunu_mor = this.add.image(width - 330,height/2,'Eslestirme_oyunu_mor')
        .setOrigin(0.5)
        .setScale(1,1.3);
        
        const Panaly = this.Eslestirme_oyunu_mor.x - 150;
        const Panalx = this.Eslestirme_oyunu_mor.y - 100;
    
        options.forEach((txt, i) => {
                const col = i % 2;
                const row = Math.floor(i / 2);

                const x = Panaly + (col * 265);
                const y = Panalx + (row * 80);

                const kart = this.ui.createDraggableImge(x, y, 'eslestirme_oyunu_kelime_kutucugu', txt, {
                    fontSize: '28px'
                });
            kart.setData('word', txt);
            kart.setData('originX', kart.x);
            kart.setData('originY', kart.y);
            kart.setData('currentSlot', null);

            kart.on('dragend', () => {
            let placed = false;
            this.slots.forEach(slot => {
                const distance = Phaser.Math.Distance.Between(kart.x, kart.y, slot.x + (slot.width/2), slot.y);
                if (distance < 100) {
                    if (slot.getData('occupiedBy') && slot.getData('occupiedBy') !== kart) {
                        this.returnToOrigin(slot.getData('occupiedBy'));
                    }
                    if (kart.getData('currentSlot')) kart.getData('currentSlot').setData('occupiedBy', null);
                    
                    kart.setPosition(slot.x + (slot.width / 2), slot.y);
                    slot.setData('occupiedBy', kart);
                    kart.setData('currentSlot', slot);
                    placed = true;
                    }
            });
            if (!placed) this.returnToOrigin(kart);
            });
        });

        this.createCheckButton(width / 2, height * 0.85);

        this.ui.createHeader('Yazim_hatasi_etkinlik',"Doğruları boşluklara sürükleyin")
        this.ui.createBottomBar('Elma', { back: "Balon" });
    }

    createSlot(x, y, Text1, Text2, correctAnswer) {
        // Arka plan şeridi
        this.add.image(x,y,'Eslestirme_oyunu_buton').setOrigin(0,0.5);

        // Metin 1 (Boyutlar 1080p için büyütüldü)
        const t1 = this.add.text(x+30, y, Text1, { fontSize: '32px', color: '#333' ,fontFamily: 'TemelYazi'}).setOrigin(0,0.5);
        
        const slot = this.add.image(t1.getBounds().right,y,'eslestirme_oyunu_kelime_kutucugu').setOrigin(0, 0.5);
    
        // Metin 2
        this.add.text(slot.getBounds().right, y, Text2, { fontSize: '32px', color: '#333',fontFamily: 'TemelYazi' }).setOrigin(0, 0.5);
        
        slot.setData('correctAnswer', correctAnswer);
        slot.setData('occupiedBy', null);
        this.slots.push(slot);
    }

    returnToOrigin(card) {
        if (card.getData('currentSlot')) card.getData('currentSlot').setData('occupiedBy', null);
        card.setData('currentSlot', null);
        this.tweens.add({
            targets: card,
            x: card.getData('originX'),
            y: card.getData('originY'),
            duration: 300,
            ease: 'Back.easeOut'
        });
    }

    createCheckButton(x, y) {
        const Kontrol = this.ui.createImgeButton(x, y, 'Kontrol_et_buton', undefined, {
            fontSize: '36px',
            ButtonColor: 0x4CAF50,
        });

        Kontrol.on('pointerdown', () => {
            for (let i = this.slots.length - 1; i >= 0; i--) {
                const slot = this.slots[i];
                const card = slot.getData('occupiedBy');

                if (card) {
                    const isCorrect = card.getData('word') === slot.getData('correctAnswer');
                    
                    if (isCorrect) {
                        card.list[0].setTint(0x00ff00);
                        card.disableInteractive();
                        this.removeSlotAtIndex(i); 
                    } else {
                        this.returnToOrigin(card);
                    }
                }
            }
        });
    }

    removeSlotAtIndex(index) {
        const slot = this.slots[index];
        
        // 1. Diziden çıkar
        this.slots.splice(index, 1);
        
        // 2. Kartın slota olan bağımlılığını temizle
        const card = slot.getData('occupiedBy');
        if(card) {
            card.setData('currentSlot', null);
        }

        // 3. Fiziksel olarak sahneden sil
        slot.destroy();
        console.log("Slot ve referanslar temizlendi.");
    }
}