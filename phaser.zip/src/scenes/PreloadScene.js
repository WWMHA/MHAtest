export class PreloadScene extends Phaser.Scene {

    constructor() {
        super('PreloadScene');
    }
    preload() {
        Object.values(this.ui.ASSETS).forEach(category => {
            Object.entries(category).forEach(([key, path]) => {
                this.load.image(key, path);
            });
        });
        this.load.font('TemelYazi', 'assets/fonts/TemelYazi.otf');
        this.load.font('TemelYazi-Bold', 'assets/fonts/TemelYazi-Bold.otf');
        this.load.audio('click', 'assets/Audio/click.mp3');
        this.load.audio('win', 'assets/Audio/win.mp3');
        
        console.log("Tüm assetler yükleniyor...");
    }

    create() {
        const createLevelData = () => ({
            t: 0,    
            f: 0,    
            time: 0  
        });
        const levelStats = Array.from({ length: 7 }, (_, i) => ({
        level: i + 1,
        ...createLevelData()
        }));
        this.registry.set('levelStats', levelStats);
        this.scene.start('Start'); // Yükleme bitince ana oyuna geç
    }
}