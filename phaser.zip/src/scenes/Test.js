class Star extends Phaser.GameObjects.Arc {
    constructor(scene) {
        // Rastgele bir konumda başlat
        super(scene, 0, 0, 2, 0, 360, false, 0xffffff);
        
        scene.add.existing(this);
        this.reset();
    }

    reset() {
        // 3D uzaydaki sanal koordinatlar
        this.z = Math.random() * 2000; // Derinlik (Z ekseni)
        this.x3D = (Math.random() - 0.5) * 2000; // X düzlemi
        this.y3D = (Math.random() - 0.5) * 2000; // Y düzlemi
    }

    update(speed, centerX, centerY) {
        // Z ekseninde bize doğru yaklaştır
        this.z -= speed;

        // Ekranın dışına çıktıysa (arkamıza geçtiyse) sıfırla
        if (this.z <= 0) {
            this.reset();
        }

        // --- 3D Projeksiyon Formülü ---
        // x_ekran = (x_3d / z) * zoom + center
        const factor = 400 / this.z; 
        this.x = this.x3D * factor + centerX;
        this.y = this.y3D * factor + centerY;

        // Derinliğe göre boyutlandırma (Z azaldıkça boyut büyür)
        this.setScale(factor * 2);
        
        // Derinliğe göre opaklık (Uzaktakiler sönük)
        this.alpha = Phaser.Math.Clamp(1.5 - (this.z / 1500), 0, 1);
    }
}
export class GameScene extends Phaser.Scene {
    constructor() {
        super('GameScene');
        this.stars = [];
        this.starCount = 400;
        this.speed = 1;
    }

    create() {
        this.centerX = this.cameras.main.width / 2;
        this.centerY = this.cameras.main.height / 2;

        // Nesneleri bir kez oluştur (Performans Dostu)
        for (let i = 0; i < this.starCount; i++) {
            this.stars.push(new Star(this));
        }
    }

    update() {
        // Render döngüsünde ağır işlemden kaçınıyoruz
        for (let star of this.stars) {
            star.update(this.speed, this.centerX, this.centerY);
        }
    }
}