export class SkoolTest extends Phaser.Scene {
    constructor() {
        super('SkoolTest');
    }

    init() {
        this.word = [
            { Name: "Aile", Icon: "", Ses: 'Aile' },
            { Name: "inci", Icon: "", Ses: 'inci' },
            { Name: "diş", Icon: "", Ses: 'diş' },
            { Name: "pil", Icon: "", Ses: 'pil' },
            { Name: "inek", Icon: "", Ses: 'inek' },
            { Name: "kedi", Icon: "", Ses: 'kedi' },
        ];
    }

    preload(){
        this.load.audio('Aile', 'assets/Audio/Word/Aile.mp3');
        this.load.audio('inci', 'assets/Audio/Word/inci.mp3');
        this.load.audio('diş', 'assets/Audio/Word/diş.mp3');
        this.load.audio('pil', 'assets/Audio/Word/pil.mp3');
        this.load.audio('inek', 'assets/Audio/Word/inek.mp3');
        this.load.audio('kedi', 'assets/Audio/Word/kedi.mp3');
    }

    create() {
        const { width, height } = this.cameras.main;
        this.ui.setBackground('Dogru_yanlis_oyunu_plan');

        Phaser.Utils.Array.Shuffle(this.word);
        this.word.forEach((q, i) => {
            const x =  width / 5 + (i * 250);
            const y = height / 3;
            this.createSlot(x, y, q.Name);
        });

        Phaser.Utils.Array.Shuffle(this.word);
        this.word.forEach((q, i) => {
            const col = i % 6;
            const row = Math.floor(i / 6);
            const x = width / 4 + (col * 200);
            const y = height / 3 *2 + (row * 100);
            this.createWord(x, y, q.Name);
        });

        this.setupDragEvents();

        this.ui.createHeader('Yazim_hatasi_etkinlik', "Doğruları boşluklara sürükleyin");
        this.ui.createBottomBar('Elma', { back: "Balon" });
    }

    createSlot(x, y, correctAnswer) {
        const zone = this.add.zone(x, y, 200, 300).setRectangleDropZone(200, 300);
        zone.setData('correctAnswer', correctAnswer);
        
        this.add.rectangle(x, y, 200, 300, 0x8a4b29).setOrigin(0.5);
        this.add.text(x, y,correctAnswer).setOrigin(0.5);
    }

    createWord(x, y, Name) {
        const kart = this.ui.createDraggableImge(x, y, 'Eslestirme_oyunu_buton', Name);
        
        kart.setScale(0.2, 1);
        if (kart.list && kart.list[1]) kart.list[1].setScale(5, 1);

        kart.setData({
            'word': Name,
            'originX': x,
            'originY': y
        });

        kart.setInteractive({ draggable: true });
    }

    setupDragEvents() {
        this.input.on('dragstart', (pointer,gameObject) => {
            const test =gameObject.getData('Ses');
            this.sound.play(test);
        });

        this.input.on('drag', (pointer, gameObject, dragX, dragY) => {
            gameObject.x = dragX;
            gameObject.y = dragY;
        });

        this.input.on('drop', (pointer, gameObject, dropZone) => {
            const isCorrect = gameObject.getData('word') === dropZone.getData('correctAnswer');

            if (isCorrect) {
                gameObject.setPosition(dropZone.x, dropZone.y);
                gameObject.disableInteractive(); // Tekrar sürüklenmesin
                
                this.tweens.add({
                    targets: gameObject,
                    scale: gameObject.scale * 1.1,
                    duration: 100,
                    yoyo: true
                });
            } else {
                this.returnToOrigin(gameObject);
            }
        });

        this.input.on('dragend', (pointer, gameObject, dropped) => {
            if (!dropped) {
                this.returnToOrigin(gameObject);
            }
        });
    }

    returnToOrigin(card) {
        this.tweens.add({
            targets: card,
            x: card.getData('originX'),
            y: card.getData('originY'),
            duration: 400,
            ease: 'Back.easeOut'
        });
    }
}