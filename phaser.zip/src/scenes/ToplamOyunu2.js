export class ToplamOyunu2 extends Phaser.Scene {
    constructor() {
        super('ToplamOyunu2');
    }

    init() {
        this.players = [];
        this.maxQuestions = 10;
    }

    create() {
        const { width, height } = this.cameras.main;
        const centerX = width / 2;

        this.ui.setBackground('Portakal_Arkaplan');
        this.add.image(centerX, 50, 'Toplama_oyun_basligi');
        this.add.text(centerX, 60, "Aşağıdaki işlemin sonucunu bulunuz", {
            fontSize: '64px',
            fontFamily: 'TemelYazi-Bold',
            color: '#000000'
        }).setOrigin();

        this.createPlayer(width * 0.25, "P1");
        this.createPlayer(width * 0.75, "P1");

        this.ui.createBottomBar('Carpim', { back: "Toplama" });
    }

    createPlayer(x, name) {
        const { height } = this.cameras.main;
        
        const player = {
            name: name,
            score: 0,
            questionCount: 0,
            currentAnswer: null,
            container: this.add.container(x, 0),
            questionText: null,
            choices: []
        };

        const bg = this.add.image(0, height * 0.35, 'Islem_paneli').setScale(0.8);
        player.questionText = this.add.text(0, height * 0.35, "", {
            fontSize: '80px', color: '#e28230', fontFamily: 'TemelYazi-Bold'
        }).setOrigin(0.5);

        player.container.add([bg, player.questionText]);

        // Butonlar
        const buttonPositions = [-220, 0, 220]; 
        for (let i = 0; i < 3; i++) {
            const btn = this.ui.createImgeButton(buttonPositions[i], height * 0.65, 'Carpma_sari', null, {
                text: "", fontFamily: 'TemelYazi-Bold', fontSize: '54px'
            }).setScale(0.7);

            btn.on('pointerdown', () => this.handleAnswer(player, btn));
            player.choices.push(btn);
            player.container.add(btn);
        }

        this.players.push(player);
        this.displayPlayerQuestion(player); // Sadece bu oyuncu için soru ver
    }

    generateQuestionData() {
        const n1 = Phaser.Math.Between(1, 20);
        const n2 = Phaser.Math.Between(1, 20);
        const correct = n1 + n2;
        let options = new Set([correct]);
        while(options.size < 3) options.add(correct + Phaser.Math.Between(-5, 10));

        return {
            text: `${n1}+${n2}`,
            correct: correct,
            options: Phaser.Utils.Array.Shuffle(Array.from(options))
        };
    }

    displayPlayerQuestion(player) {

        const data = this.generateQuestionData();
        player.currentAnswer = data.correct;

        player.container.setAlpha(0);
        this.tweens.add({
            targets: player.container,
            alpha: 1,
            duration: 400
        });

        player.questionText.setText(data.text);
        player.choices.forEach((btn, i) => {
            const txt = btn.list.find(c => c.type === 'Text');
            if (txt) txt.setText(data.options[i]);
            btn.answerValue = data.options[i];
            btn.setInteractive().setAlpha(1);
        });
    }

    handleAnswer(player, selectedBtn) {
        player.choices.forEach(btn => btn.disableInteractive());

        const isCorrect = selectedBtn.answerValue === player.currentAnswer;
        
        if (isCorrect) {
            this.ui.triggerFeedback(selectedBtn, 'Tebrikler', '#00ff00');
        } else {
            this.ui.triggerFeedback(selectedBtn, 'Hata!', '#ff0000');
        }

        this.time.delayedCall(1000, () => {
            this.displayPlayerQuestion(player);
        });
    }
}