export class Start extends Phaser.Scene {
    constructor() {
        super('Start');
    }

     preload() {
        this.load.audio('Arkaplanses', 'assets/Audio/Arkaplanses.mp3');
        this.Level = [
            {text :"Yazim Hatasi Etkinlik",Scene :'Yazim'},
            {text :"Doğru Yanlış Oyunu",Scene :'DogruYanlis'},
            {text :"Balon patlatma",Scene :'Balon'},
            {text :"Eşleştirme oyunu",Scene :'Eslestir'},
            {text :"Elma Toplama",Scene :'Elma'},
            {text :"Çarpma",Scene :'Carpim'},
            {text :"Toplama",Scene :'Toplama'},
        ];
    }
    create() {this.ui
        //#region Background
        const { width, height } = this.cameras.main;
        const background = this.add.tileSprite(width/2, height/2, width, height, 'Bulut_plan').setScale(1.2).setDepth(-1);
        const logo = this.add.image(960, 210, 'SKOOL_logo').setDepth(1);
        const Bulutlar = this.add.image(width/2, height-450, 'Bulutlar').setDepth(0);
        this.tweens.add({//Bulutlar
            targets: Bulutlar,
            y: height/2,
            duration: 4000,
            ease: 'Sine.inOut',
            yoyo: true,
            loop: -1
        });
        this.tweens.add({//Logo
            targets: logo,
            y: 230,
            duration: 4000,
            ease: 'Sine.inOut',
            yoyo: true,
            loop: -1
        });
        this.tweens.add({//Background
            targets: background,
            y: 500,
            duration: 4000,
            ease: 'Sine.inOut',
            yoyo: true,
            loop: -1
        });
        //#endregion Background
        
        this.sound.play('Arkaplanses',{ loop:true,volume: 0.2});
        this.events.once('shutdown', () => this.sound.stopAll());

        //#region MERKEZ BUTONLAR
        this.Level.forEach((data,index) => {
            const col = Math.floor(index / 5);
            const row = index % 5;
            const x = width/2 - 300 + (col * 600);
            const y =height/2 -100 + (row * 100);
            this.ui.createImgeButton(
            x, y,
            'Anasayfa_buton', 
            data.Scene,{
            text :data.text,
            fontSize : '36px',
            ButtonColor: 0x4CAF50,
            textColor: '#361c03'
        });
        });
        //#endregion
        //this.sound.play('Arkaplanses');
    }
}