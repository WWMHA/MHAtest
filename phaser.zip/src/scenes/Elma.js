export class Elma extends Phaser.Scene {
    constructor() {
        super('Elma');
    }

    init() {
        this.activeoranges = [];
        this.count=0;
    }

    create() {
        this.startTime  = Date.now();
        const { width, height } = this.cameras.main;
        
        // --- ARKA PLAN ---
        this.add.image(width / 2, height / 2, 'Bulut_plan').setDisplaySize(width, height);
        const Bulutlar = this.add.image(width/2, height/2 - 200, 'Bulutlar');
        this.add.image(width / 2, height * 0.75, 'Cimen_').setDisplaySize(width, height).setScale(1, 0.8);
        
        this.tweens.add({
            targets: Bulutlar,
            y: height/4,
            duration: 4000,
            ease: 'Sine.inOut',
            yoyo: true,
            loop: -1
        });
        
        // --- AĞAÇLAR ---
        const treeLeft = this.add.image(width * 0.25, height / 2, 'Agac_sol_');
        const treeRight = this.add.image(width * 0.75, height / 2, 'Agac_sag_');

        // --- SEPET ---
        const sepet = this.add.image(width / 2, height * 0.75, 'Sepet').setScale(1).setDepth(1);
        const sepetBounds = sepet.getBounds();

        // --- VERİ VE KARIŞTIRMA ---
        let ekler = [
            { metin: 'T', dogru: true },
            { metin: 'T', dogru: true },
            { metin: 'F', dogru: false },
            { metin: 'T', dogru: true },
            { metin: 'F', dogru: false },
            { metin: 'T', dogru: true },
            { metin: 'F', dogru: false },
            { metin: 'T', dogru: true }
            ];
        
        Phaser.Utils.Array.Shuffle(ekler);

        // --- PORTAKAL YERLEŞTİRME MANTIĞI ---
        const orangePositions = [
            { x: treeLeft.x + 50, y: treeLeft.y - 250 },
            { x: treeLeft.x + 60, y: treeLeft.y - 80 },
            { x: treeLeft.x - 120, y: treeLeft.y + 20 },
            { x: treeLeft.x + 150, y: treeLeft.y + 100 },
            //--------------------------------------------//
            { x: treeRight.x - 50, y: treeRight.y - 250 },
            { x: treeRight.x - 60, y: treeRight.y - 80 },
            { x: treeRight.x + 120, y: treeRight.y + 20 },
            { x: treeRight.x - 150, y: treeRight.y + 100 }
        ];

        ekler.forEach((data, index) => {
            const pos = orangePositions[index % orangePositions.length];

            const orange = this.ui.createDraggableImge(pos.x, pos.y, 'Portakal', data.metin, {
                TextColor: "#ffffff", 
                scale: 1, 
                fontSize: '32px'
            }).setDepth(2)
            .setData({
                'dogruMu': data.dogru,
                'baslangicX': pos.x,
                'baslangicY': pos.y
            });

            this.setuporangeEvents(orange, sepet, sepetBounds);
            this.activeoranges.push(orange);
        });

        this.ui.createHeader('Yazim_hatasi_etkinlik', "Doğru ekleri sepete topla!");
        this.ui.createBottomBar('Yazim', { back: "Eslestir" });
    }

    setuporangeEvents(orange, sepet, sepetBounds) {
        orange.on('dragend', () => {
            if (Phaser.Geom.Intersects.RectangleToRectangle(orange.getBounds(), sepetBounds)) {
                if (orange.getData('dogruMu')) {
                    this.count++;
                    if(this.count == 2){
                        sepet.setTexture("portakal2");
                    }
                    if(this.count == 3){
                        sepet.setTexture("portakal3");
                    }
                    this.tweens.add({
                        targets: orange,
                        scale: 0.1,
                        alpha: 0,
                        y: sepet.y,
                        duration: 300,
                        onComplete: () => this.removeorange(orange)
                    });
                } else {
                    if (orange.list && orange.list[0]) {
                        orange.list[0].setTint(0xff0000);
                        this.time.delayedCall(500, () => orange.list[0].clearTint());
                    }
                    this.returnorange(orange);
                }
            } else {
                this.returnorange(orange);
            }
        });
    }

    returnorange(orange) {
        this.tweens.add({
            targets: orange,
            x: orange.getData('baslangicX'),
            y: orange.getData('baslangicY'),
            duration: 400,
            ease: 'Back.easeOut'
        });
    }

    removeorange(orange) {
        const index = this.activeoranges.indexOf(orange);
        if (index > -1) this.activeoranges.splice(index, 1);
        orange.destroy();

        const remains = this.activeoranges.filter(a => a.getData('dogruMu'));
        if (remains.length === 0) {
            // Skor hesaplama mantığını buraya bağladık
            this.ui.showFinalScreen(100, 120, 150); 
        }
    }
}