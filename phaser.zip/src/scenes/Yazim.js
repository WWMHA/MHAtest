export class Yazim extends Phaser.Scene {
    constructor() {
        super('Yazim');
    }

    preload() {
        this.TrueA = [];    //Yeşil kutucuk
        this.FalseA = [];   //Kırmızı kutucuk
        this.Cards = [//{text:,answer:}
            { text: "Yanlış", answer: 'TrueA'},
            { text: "Herkez", answer: 'FalseA'},
            { text: "Tren", answer: 'TrueA'},
            { text: "Süpriz", answer: 'FalseA'},
            { text: "Eğlence", answer: 'TrueA'},
            { text: "Gazete", answer: 'TrueA'},
        ];
        this.load.audio('Etkinlik1', 'assets/Audio/Level/E1.mp3');
    }
    create() {
        this.startTime  = Date.now();
        this.stats = this.registry.get('levelStats');
        //#region Background
        const { width, height } = this.cameras.main;
        const centerX = width/ 2;
        const centerY = height/ 2;
        this.ui.setBackground('Portakal_Arkaplan');
        //#endregion Background      
        //#region Alanların oluşturulması
        this.block1 = this.add.image(centerX-540, centerY+20,'Kirmizi_kutu')
            .setData('tip', 'FalseA');

        this.block2 = this.add.image(centerX+580, centerY,'Yesil_Kutu')
            .setData('tip', 'TrueA');
        const bloklar = [this.block1, this.block2];
        //#endregion
        //cevapların oluşturulması
        for(let i=0;i < this.Cards.length;i++){
            const startX = centerX;
            const startY = height/4 + (80 * i);
            const Kart =  this.ui.createDraggableImge(startX,startY,'Sag_sol_buton', this.Cards[i].text);
            Kart.setData('tip', this.Cards[i].answer);
            Kart.on("dragstart",()=>{this.sound.play('click');})
            Kart.on("dragend", () => {
                        this.sound.play('click');
                        Kart.setAlpha(1);  
                        let yerlesti = false;
                        for (const blok of bloklar) {
                            if (Phaser.Geom.Intersects.RectangleToRectangle(Kart.getBounds(), blok.getBounds())) {
                                this.removeFromOldList(Kart);
                                this.sortInBlock(blok, Kart);
                                yerlesti = true;
                                break;
                            }
                        }
                        if (!yerlesti) {
                            this.removeFromOldList(Kart); // Blok dışına çekilirse listeden sil
                            this.tweens.add({
                                targets: Kart,
                                x: startX,
                                y: startY,
                                duration: 400,
                                ease: 'Back.easeOut'
                            });
                        }
            });
        }
        //Kontrol tuşunun oluşturulması 
        const Kontrol = this.ui.createImgeButton(centerX, centerY+300,'Kontrol_et_buton', undefined);
        Kontrol.on("pointerdown", () => {
            if(this.TrueA.length + this.FalseA.length == this.Cards.length){
                this.sound.play('win', { rate: 1.25 });
                this.stats[0].time = ((Date.now() - this.startTime)/1000).toFixed(0);
                console.log(this.stats[0].time + "sn");
                this.checkAnswer();
                Kontrol.disableInteractive();
            }
        });

        this.ui.createHeader('Yazim_hatasi_etkinlik',"Doğrular sağa,yanlışları sola sürükleyin","Etkinlik1")
        this.ui.createBottomBar('DogruYanlis');
    }
    checkAnswer(){
        let correctCount = 0;
        let wrongcount=0;
        for(const cevaplar of this.TrueA){
            if(cevaplar.getData('tip') == this.block2.getData('tip')){
                this.ui.triggerFeedback(cevaplar,"+10",'#00ff00');
                correctCount++;
            }
            else{
                this.ui.triggerFeedback(cevaplar,"-5",'#ff1313');
                wrongcount++;
            }
            cevaplar.disableInteractive();
        }
        for(const cevaplar of this.FalseA){
            if(cevaplar.getData('tip') == this.block1.getData('tip')){
                this.ui.triggerFeedback(cevaplar,"+10",'#00ff00');
                correctCount++;
            }
            else{
                this.ui.triggerFeedback(cevaplar,"-5",'#ff1313');
                wrongcount++;
            }
            cevaplar.disableInteractive();
        }
        this.stats[0].t = correctCount;
        this.stats[0].f = wrongcount;
        this.registry.set('levelStats', this.stats);
        const test = this.registry.get('levelStats');
        console.log("True : "+ test[0].t +"\n"+ "False : "+ test[0].f + "\n"+ "Time : "+ test[0].time);
        this.ui.showFinalScreen(correctCount,correctCount+wrongcount,correctCount * 10 + wrongcount * -5);
    }
    removeFromOldList(container) {
            const oldBlockType = container.getData('currentBlock');
            if (oldBlockType === 'TrueA') {
                this.TrueA = this.TrueA.filter(item => item !== container);
            } else if (oldBlockType === 'FalseA') {
                this.FalseA = this.FalseA.filter(item => item !== container);
            }
    }
    sortInBlock(block, Kart) {
            const type = block.getData('tip');
            const targetArray = (type === 'TrueA') ? this.TrueA : this.FalseA;

            targetArray.push(Kart);
            Kart.setData('currentBlock', type);

            const spacing = 100;
            const startY = block.y - (block.height / 2) + 60;
            const centerX = block.x;

            targetArray.forEach((item, index) => {
                this.tweens.add({
                    targets: item,
                    x: centerX,
                    y: startY + (index * spacing),
                    duration: 300,
                    ease: 'Cubic.easeOut'
                });
            });
    }
}