export class CarpimOyunu2 extends Phaser.Scene {
    constructor() {
        super('CarpimOyunu2');
    }

    init() {
        // Her oyuncu için veri tutacağız
        this.players = [
            { questionText: null, choices: [], currentAnswer: 0 },
            { questionText: null, choices: [], currentAnswer: 0 }
        ];
    }

    create() {
        const { width, height } = this.cameras.main;

        this.ui.setBackground('Portakal_Arkaplan');
        this.add.image(width / 2, 0, 'Carpma_oyun_baslik').setOrigin(0.5, 0);
        this.add.text(width / 2, 60, "Aşağıdaki işlemin sonucunu bulunuz", {
            fontSize: '64px',
            fontFamily: 'TemelYazi-Bold',
            color: '#000000'
        }).setOrigin(0.5);

        // İki oyuncuyu yan yana oluştur
        const xPositions = [width * 0.25, width * 0.75];

        xPositions.forEach((px, index) => {
            const player = this.players[index];

            // Arkaplan paneli
            this.add.image(px, height / 3, 'Islem_paneli').setScale(0.8);

            // Soru metni
            player.questionText = this.add.text(px, height / 3, "", {
                fontSize: '100px',
                color: '#e28230',
                fontFamily: 'TemelYazi-Bold'
            }).setOrigin(0.5);

            // Seçenek butonları
            const offsets = [-250, 0, 250];
            offsets.forEach(offsetX => {
                const btn = this.ui.createImgeButton(px + offsetX, (height / 3) * 2, 'Carpma_sari', null, {
                    text: "",
                    fontFamily: 'TemelYazi-Bold',
                    fontSize: '64px'
                }).setScale(0.8);

                btn.label = btn.list.find(c => c.type === 'Text');
                btn.on('pointerdown', () => this.handleAnswer(player, btn));
                player.choices.push(btn);
            });
        });

        this.players.forEach(p => this.displayPlayerQuestion(p));
        this.ui.createBottomBar('Toplama', { back: 'Carpim' });
    }

    generateQuestionData(min, max) {
        const num1 = Phaser.Math.Between(min, max);
        const num2 = Phaser.Math.Between(min, max);
        const correct = num1 * num2;

        let answers = [correct, correct + Phaser.Math.Between(1, 5), Math.abs(correct - Phaser.Math.Between(1, 5))];
        answers = [...new Set(answers)];
        while (answers.length < 3) answers.push(correct + answers.length + 1);

        return {
            text: `${num1}x${num2} = ?`,
            correct,
            options: Phaser.Utils.Array.Shuffle(answers)
        };
    }

    displayPlayerQuestion(player) {
        const data = this.generateQuestionData(1, 10);
        player.currentAnswer = data.correct;

        player.questionText.setText(data.text);
        player.choices.forEach((btn, i) => {
            if (btn.label) btn.label.setText(data.options[i]);
            btn.answerValue = data.options[i];
            btn.setInteractive().setAlpha(1);
        });
    }

    handleAnswer(player, selectedBtn) {
        // Çift tıklamayı önle
        player.choices.forEach(btn => btn.disableInteractive());

        const isCorrect = selectedBtn.answerValue === player.currentAnswer;
        this.ui.triggerFeedback(selectedBtn, isCorrect ? 'Tebrikler!' : 'Hata!', isCorrect ? '#00ff00' : '#ff0000');

        this.time.delayedCall(1000, () => {
            if (this.scene.isActive()) {
                player.choices.forEach(btn => btn.setInteractive());
                this.displayPlayerQuestion(player);
            }
        });
    }
}