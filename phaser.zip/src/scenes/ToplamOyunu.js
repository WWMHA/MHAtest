export class ToplamOyunu extends Phaser.Scene {
    constructor() {
        super('ToplamOyunu');
    }

    init() {
        this.questionsCount = 0;
        this.maxQuestions = 10;
        this.correctAnswersCount = 0;
        this.choices = []; 
    }

    create() {
        const { width, height } = this.cameras.main;
        const centerX = width / 2;

        this.ui.setBackground('Portakal_Arkaplan');
        
        this.add.image(centerX, 0, 'Toplama_oyun_basligi').setOrigin(0.5, 0);
        
        this.add.text(centerX, 120, "Aşağıdaki toplama işleminin sonucunu bulunuz", {
            fontSize: '64px',
            fontFamily: 'TemelYazi-Bold',
            color: '#000000'
        }).setOrigin(0.5);

        this.add.image(centerX, height / 3, 'Islem_paneli');
        
        this.questionText = this.add.text(centerX, height / 3, "", {
            fontSize: '150px',
            color: '#e28230',
            fontFamily: 'TemelYazi-Bold',
            align: 'center'
        }).setOrigin(0.5);

        this.createChoices();
        this.ui.createBottomBar('Carpim', { back: "Toplama" }); // Geri dönüş menüye ayarlandı
        this.displayQuestion();
    }

    createChoices() {
        const { width, height } = this.cameras.main;
        const centerX = width / 2;
        const positions = [centerX - 350, centerX, centerX + 350];

        for (let i = 0; i < 3; i++) {
            // Buton görselini 'Toplama_sari' veya mevcut butonunla değiştirebilirsin
            const btn = this.ui.createImgeButton(positions[i], (height / 3) * 2, 'Carpma_sari', null, {
                text: "",
                fontFamily: 'TemelYazi-Bold',
                fontSize: '96px'
            });

            btn.on('pointerdown', () => this.handleAnswer(btn));
            this.choices.push(btn);
        }
    }

    generateQuestionData(min, max) {
        const num1 = Phaser.Math.Between(min, max);
        const num2 = Phaser.Math.Between(min, max);
        const correct = num1 + num2; // Toplama işlemi yapıldı
        
        let answers = [
            correct, 
            correct + Phaser.Math.Between(1, 10), 
            Math.abs(correct - Phaser.Math.Between(1, 10))
        ];

        // Benzersiz cevaplar oluşturma
        answers = [...new Set(answers)];
        while(answers.length < 3) answers.push(correct + answers.length + 1);
        
        return {
            text: `${num1}+${num2} = ?`,
            correct: correct,
            options: Phaser.Utils.Array.Shuffle(answers)
        };
    }

    displayQuestion() {
        const { width } = this.cameras.main;
        const centerX = width / 2;
        const data = this.generateQuestionData(1, 50);
        this.currentCorrectResult = data.correct;

        // Sahne temizleme ve animasyonla yeni soru getirme
        this.tweens.add({
            targets: [this.questionText, ...this.choices],
            x: "-=200",
            alpha: 0,
            duration: 250,
            ease: 'Power2',
            onComplete: () => {
                this.questionText.setText(data.text);
                this.questionText.setPosition(centerX + 200, this.questionText.y); 

                const choicePositions = [centerX - 350, centerX, centerX + 350];
                
                this.choices.forEach((btn, i) => {
                    const txt = btn.list.find(c => c.type === 'Text');
                    if(txt) txt.setText(data.options[i]);
                    btn.answerValue = data.options[i];
                    
                    btn.setPosition(choicePositions[i] + 200, btn.y); 
                    btn.setAlpha(0);
                    btn.setInteractive();
                });

                // Giriş animasyonu
                this.tweens.add({
                    targets: this.questionText,
                    x: centerX,
                    alpha: 1,
                    duration: 500,
                    ease: 'Back.out'
                });

                this.choices.forEach((btn, i) => {
                    this.tweens.add({
                        targets: btn,
                        x: choicePositions[i],
                        alpha: 1,
                        delay: 100 * (i + 1),
                        duration: 500,
                        ease: 'Back.out'
                    });
                });
            }
        });
    }

    handleAnswer(selectedBtn) {
        this.choices.forEach(btn => btn.disableInteractive());

        if (selectedBtn.answerValue === this.currentCorrectResult) {
            this.correctAnswersCount++;
            this.ui.triggerFeedback(selectedBtn, 'Doğru! +10', '#00ff00');
        } else {
            this.ui.triggerFeedback(selectedBtn, 'Hata!', '#ff0000');
        }

        this.time.delayedCall(1500, () => {
            this.questionsCount++;
            if (this.questionsCount < this.maxQuestions) {
                this.displayQuestion();
            } else {
                this.ui.showFinalScreen(this.correctAnswersCount, this.maxQuestions, this.correctAnswersCount * 10);
            }
        });
    }
}