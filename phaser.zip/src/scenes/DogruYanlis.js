export class DogruYanlis extends Phaser.Scene {
    constructor() {
        super('DogruYanlis');
    }

    init() {
        this.currentQuestionIndex = 0;
        this.correctAnswersCount = 0;
        this.questions = [
            { text: "Cümleler her zaman büyük harfle başlar.", answer: true, sound: 'Soru1' },
            { text: "Özel isimler küçük harfle yazılabilir.", answer: false, sound: 'Soru2' },
            { text: "Bağlaç olan 'de' ve 'da' kelimeden ayrı yazılır.", answer: true, sound: 'Soru3' }
        ];
    }

    preload() {
        this.load.audio('Soru1', 'assets/Audio/Level/ses1.mp3');
        this.load.audio('Soru2', 'assets/Audio/Level/Soru2.mp3');
        this.load.audio('Soru3', 'assets/Audio/Level/Soru3.mp3');
    }

    create() {
        this.events.once('shutdown', () => this.sound.stopAll());
        this.startTime  = Date.now();
        //#region Background
        const { width, height } = this.cameras.main;
        const centerX = width / 2;
        const centerY = height / 2;
        this.ui.setBackground('Dogru_yanlis_oyunu_plan');
        //#endregion
        // Soru Metni
        this.questionText = this.add.text(centerX, centerY - 350, "", {
            fontSize: '40px', 
            color: '#151f2b', 
            fontFamily: 'TemelYazi',
            fontWeight: 'bold', 
            align: 'center', 
            wordWrap: { width: 600 }
        }).setOrigin(0.5);

        // Ses Button 
        this.Icon = this.add.image(centerX, this.questionText.y, 'Ses_buton')
            .setInteractive({ useHandCursor: true })
            .setScale(0.06).setOrigin(1,0);

        this.trueBtn = this.createOptionButton(centerX, centerY - 220, "Doğru", true);
        this.falseBtn = this.createOptionButton(centerX, centerY - 100, "Yanlış", false);
        
        //#region Animasyon
        const carpi   = this.add.image(centerX - 150,height-300,'Dogru_yanlis_oyunu_carpi_').setScale(1.1);
        const tik  = this.add.image(centerX + 150,height-300,'Dogru_yanlis_oyunu_tik');
        this.tweens.add({
            targets: [tik],
            scale: 1.1,
            yoyo: true,
            loop: -1,
            duration: 1200,
        });
        this.tweens.add({
            targets: [carpi],
            scale: 1,
            yoyo: true,
            loop: -1,
            duration: 1200,
        });
        //#endregion
        
        this.displayQuestion();
        this.ui.createBottomBar('Balon', { back: "Yazim" });
        this.ui.createHeader('Yazim_hatasi_etkinlik',"")
    }

    createOptionButton(x, y, label, value) {
        const btn = this.ui.createImgeButton(x, y, 'Dogru_yanlis_oyunu_buton', null, {
            text : label,
            fontSize: '48px',
            scale: 1.1
        });
        
        btn.on('pointerdown', () => this.checkanswer(value, btn));
        
        // Hover efektleri (Sadece yandaki yazı değil tüm buton etkilenir)
        btn.on('pointerover', () => btn.setScale(1.05));
        btn.on('pointerout', () => btn.setScale(1));

        return btn;
    }

    displayQuestion() {
    const centerX = this.cameras.main.width / 2;
    const q = this.questions[this.currentQuestionIndex];
    const iconOffset = 400;

    this.tweens.add({
        targets: [this.questionText, this.trueBtn, this.falseBtn, this.Icon],
        x: "-=200",
        alpha: 0,
        duration: 250,
        ease: 'Power1',
        onComplete: () => {
            this.questionText.setText(q.text);
            
            if (this.currentSound) this.currentSound.stop();
            this.currentSound = this.sound.add(q.sound);

            this.Icon.removeAllListeners('pointerdown');
            this.Icon.on('pointerdown', () => {
                this.tweens.add({ targets: this.Icon, scale: 0.08, duration: 100, yoyo: true });
                this.currentSound.play();

            });

            this.questionText.x = centerX + 200;
            this.trueBtn.x = centerX + 200;
            this.falseBtn.x = centerX + 200;
            this.Icon.x = centerX;

            this.tweens.add({
                targets: [this.questionText, this.trueBtn, this.falseBtn],
                x: centerX,
                alpha: 1,
                duration: 500,
                ease: 'Back.easeOut',
                onComplete: () => {
                    this.tweens.add({
                    targets: this.Icon,
                    x: this.questionText.getBounds().left,
                    alpha: 1,
                    duration: 500,
                    ease: 'Back.easeOut',
                    onComplete: () => {
                        this.trueBtn.setInteractive();
                        this.falseBtn.setInteractive();
                        ;
                }
                    });
                    this.currentSound.play(); 
                }
            });
        }
    });
}
    checkanswer(userChoice, selectedBtn) {
        const currentQ = this.questions[this.currentQuestionIndex];
        const isCorrect = userChoice === currentQ.answer;
        
        this.trueBtn.disableInteractive();
        this.falseBtn.disableInteractive();

        if (isCorrect) {
            this.correctAnswersCount++;
            this.ui.triggerFeedback(selectedBtn, 'Tebrikler! +10','#00ff00');
        } else {
            this.ui.triggerFeedback(selectedBtn, 'Dikkat Et! -5', '#ff0000');
        }
        
        this.time.delayedCall(1000, () => {
            this.currentQuestionIndex++;
            if (this.currentQuestionIndex < this.questions.length) {
                this.displayQuestion();
            } else {
                this.registry.set('Level1Time',((Date.now() - this.startTime)/1000).toFixed(0));
                console.log(this.registry.get('Level1Time') + "sn");
                this.ui.showFinalScreen(this.correctAnswersCount, this.questions.length, this.correctAnswersCount * 10);
            }
        });
    }
}