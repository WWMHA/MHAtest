export class Toplama extends Phaser.Scene {
    constructor() {
        super('Toplama');
    }
    
    create() {
        const { width, height } = this.cameras.main;
        const centerX = width / 2;

        this.ui.setBackground('Portakal_Arkaplan');

        this.add.image(centerX, 0, 'Toplama_oyunu_Baslik').setOrigin(0.5, 0);
        this.add.image(width/2, 0, 'Toplama_oyunu').setOrigin(0.5,0);
        
        const btnStyle = {
            fontSize: '64px',
            fontFamily: 'TemelYazi-Bold',
            textColor: '#361c03'
        };
        const btnTek = this.ui.createImgeButton(centerX, height / 2, 'Toplama_oyunu_buton', null, {
            text: "Tek Oyuncu",
            ...btnStyle
        });

        const btnCift = this.ui.createImgeButton(centerX, height / 2 + 160, 'Toplama_oyunu_buton', null, {
            text: "İki Oyuncu",
            ...btnStyle
        });

        this.add.image(btnTek.x - 190, btnTek.y-10, 'Profil_buton').setScale(0.06).setOrigin(0.5);
        this.add.image(btnCift.x - 190, btnCift.y-10, 'Profil2_buton').setScale(0.06).setOrigin(0.5);

        // Tıklama Olayları (Event Listeners)
        btnTek.setInteractive().on('pointerdown', () => {
            this.scene.start('ToplamOyunu'); 
        });

        btnCift.setInteractive().on('pointerdown', () => {
            this.scene.start('ToplamOyunu2'); 
        });
        this.createBottomBar();
    }
    createBottomBar(config = {}) {
        const { 
            width = this.cameras.main.width,
            height = this.cameras.main.height,
            bar = 'Kontrol_cubuk',
            button = 'Onceki_sonraki_anamenu_buton',
        } = config;
        
        const bottomBarBg = this.add.image(width / 2, height- 50, bar)
            .setScale(1, 1)
            .setOrigin(0.5);
    
        const homeBtn = this.ui.createImgeButton(width / 2,height- 50, button,'Start', {
            text : "Ana menü",
            scale: 0.8
        });

    }
}