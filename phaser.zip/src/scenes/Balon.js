export class Balon extends Phaser.Scene {
    constructor() {
        super('Balon');
    }

    init() {
        this.score = 0;
        this.correctCount = 0;
        this.clickedCount = 0;
        this.totalCorrectTarget = 0;
        this.GameOver = false;
    }

    preload() {
        this.wordList = [
            { text: 'Çiçek', isCorrect: false },
            { text: 'Manisa', isCorrect: true },
            { text: 'Masa', isCorrect: false },
            { text: 'Köpek', isCorrect: false },
            { text: 'Ayşe', isCorrect: true },
        ];
        this.ballonCollor = [
            'pembe',
            'sari',
            'turkuaz',
            'turuncu',
            'yesil'
        ];
        Phaser.Utils.Array.Shuffle(this.wordList);
        this.totalCorrectTarget = this.wordList.filter(w => w.isCorrect).length;

        this.load.audio('Etkinlik3', 'assets/Audio/Level/E3.mp3');
        this.load.audio('pop', 'assets/Audio/pop.mp3');
    }

    create() {
        this.startTime  = Date.now();
        //#region Background
        const { width, height } = this.cameras.main;
        this.cameras.main.setBackgroundColor('#E3F2FD');
        this.background = this.add.image(width / 2, height / 2, 'Balon_plan');
        this.background.setDisplaySize(width, height);
        const logo2 = this.add.image(width/2, height-450, 'Bulutlar').setDepth(0);
        this.tweens.add({
            targets: logo2,
            y: height/2,
            duration: 4000,
            ease: 'Sine.inOut',
            yoyo: true,
            loop: -1
        });
        this.tweens.add({
            targets: this.background,
            y: 500,
            duration: 4000,
            ease: 'Sine.inOut',
            yoyo: true,
            loop: -1
        });
        //#endregion Background
        
        this.spawnBalloons();

        this.ui.createHeader('Buyuk_harflerin_yazimi',"Her zaman büyük harfle başlayan sözcüklerin bulunduğu balonları patlatalım","Etkinlik3")
        this.ui.createBottomBar('Eslestir', { back: "DogruYanlis" });
    }


    spawnBalloons() {
        const { width, height } = this.cameras.main;
        
        const cols = 5;
        const cellWidth = width / (cols + 1);
        const cellHeight = height /2;

        this.wordList.forEach((data, index) => {
            const col = index % cols;//Kaçıncı Sütun 
            const row = Math.floor(index / cols);//Kaçıncı satır (Floor bir küçük değere yuvarlama)
            const x = cellWidth * (col + 1) + (Math.random() * 50 - 25);
            const y = cellHeight * (row + 1) + (Math.random() * 50 - 25);
            
            const balloon = this.createSingleBalloon(x, y, data);
        });
    }

    createSingleBalloon(x, y, data) {
        const container = this.add.container(x, y);
        
        const randomColor = Phaser.Utils.Array.GetRandom(this.ballonCollor);
        const sprite = this.add.sprite(0, 0, randomColor);
        sprite.setScale(1);

        const label = this.add.text(0, -200, data.text, { 
            fontSize: '32px', 
            fill: '#000', 
            fontFamily: 'Arial',
            fontWeight: 'bold',
            padding: { x: 5, y: 2 }
        }).setOrigin(0.5);

        container.add([sprite, label]);

        container.setSize(sprite.displayWidth, sprite.displayHeight);
        container.setInteractive({ useHandCursor: true });

        container.on('pointerdown', () => {
                if(!this.GameOver)this.BalloonClick(data, container)
        });
        
        this.BallonMove(container);//Harket
        return container;
    }

    BallonMove(target) {
        this.tweens.add({
            targets: target,
            y: target.y - 30,
            x: target.x + (Math.random() * 20 - 10),
            duration: 2000 + Math.random() * 1000,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.easeInOut'
        });
    }

    BalloonClick(data, container) {
        this.clickedCount++;
        
        if (data.isCorrect) {
            this.score += 20;
            this.correctCount++;
            this.BalloonEffect('+20', '#2ecc71', container.x, container.y);
            this.tweens.add({
                targets: container,
                scale: 1.5,
                alpha: 0,
                duration: 200,
                onComplete: () => container.destroy()
            });
            this.sound.play('pop');
        } 
        else {
            this.score = Math.max(0, this.score - 10);
            this.BalloonEffect('-10', '#e74c3c', container.x, container.y);
            
            
            // Yanlış efekti (sallanma)
            this.tweens.add({
                targets: container,
                x: container.x + 10,
                duration: 50,
                yoyo: true,
                repeat: 5
            });
        }
        
        this.checkGameOver();
    }

    BalloonEffect(message, color, x, y) {
        //Yazı
        const feedback = this.add.text(x, y, message, { 
            fontSize: '64px', 
            fill: color, 
            fontFamily: 'Arial Black',
            stroke: '#fff', 
            strokeThickness: 6 
        }).setOrigin(0.5).setDepth(50);

        this.tweens.add({
            targets: feedback,
            y: y - 150,
            alpha: 0,
            duration: 1000,
            onComplete: () => feedback.destroy()
        });
    }

    checkGameOver() {
        if (this.correctCount === this.totalCorrectTarget) {
            this.GameOver = true;
            this.time.delayedCall(200, () => 
            this.ui.showFinalScreen(this.correctCount,this.clickedCount,this.correctCount*20 + (this.correctCount-this.clickedCount)*10));
            this.sound.play('win');
        }
    }
}