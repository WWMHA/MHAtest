export class UIPlugin extends Phaser.Plugins.ScenePlugin {
    boot() {}
    ASSETS = {
        // UI Arka Planlar
        UI: {
            Dogru_yanlis_oyunu_carpi_: 'assets/Parcalar/Dogru_yanlis_oyunu_carpi_.webp',
            Buyuk_harflerin_yazimi: 'assets/Parcalar/Buyuk_harflerin_yazimi.webp',
            Dogru_yanlis_oyunu_tik: 'assets/Parcalar/Dogru_yanlis_oyunu_tik.webp',
            Eslestirme_oyunu_buton: 'assets/Parcalar/Eslestirme_oyunu_buton.webp',
            Yazim_hatasi_etkinlik: 'assets/Parcalar/Yazim_hatasi_etkinlik.webp',
            Eslestirme_oyunu_mor : 'assets/Parcalar/Eslestirme_oyunu.webp',
            Kontrol_cubuk: 'assets/Parcalar/Kontrol_cubuk.webp',
            Kirmizi_kutu: 'assets/Parcalar/Kirmizi_kutu.webp',
            Yesil_Kutu: 'assets/Parcalar/Yesil_Kutu.webp',
            SKOOL_logo: 'assets/Parcalar/SKOOL_logo.webp',
            portakal2 : 'assets/Parcalar/2_portakal.webp',
            portakal3 : 'assets/Parcalar/3_portakal.webp',
            Agac_sag_: 'assets/Parcalar/Agac_sag_.webp',
            Agac_sol_: 'assets/Parcalar/Agac_sol_.webp',
            Portakal : 'assets/Parcalar/Portakal.webp',
            Sepet : 'assets/Parcalar/Sepet.webp',
        },
        // Butonlar
        BUTTONS: {
            Ses_buton: 'assets/Parcalar/Ses_buton.webp',
            Anasayfa_buton: 'assets/Parcalar/Anasayfa_buton.webp',
            eslestirme_oyunu_kelime_kutucugu: 'assets/Parcalar/eslestirme_oyunu_kelime_kutucugu.webp',
            Kontrol_et_buton: 'assets/Parcalar/Kontrol_et_buton.webp',
            Onceki_sonraki_anamenu_buton: 'assets/Parcalar/Onceki_sonraki_anamenu_buton.webp',
            Sag_sol_buton: 'assets/Parcalar/Sag_sol_buton.webp',
            Dogru_yanlis_oyunu_buton: 'assets/Parcalar/Dogru_yanlis_oyunu_buton.webp',
        },
        BACKGROUND : {
            Bulut_plan : 'assets/Parcalar/Bulut_plan.webp',
            Balon_plan : 'assets/Parcalar/Balon_patlatma_oyunu.webp',
            Bulutlar : 'assets/Parcalar/Bulutlar_.webp',
            Cimen_ : 'assets/Parcalar/Cimen_.webp',
            Portakal_Arkaplan : 'assets/Parcalar/Portakal_Arkaplan.webp',
            Dogru_yanlis_oyunu_plan: 'assets/Parcalar/Dogru_yanlis_oyunu_plan.webp',
        },
        Balon : {
            pembe : 'assets/Parcalar/Balon_pembe.webp',
            sari : 'assets/Parcalar/Balon_sari.webp',
            turkuaz : 'assets/Parcalar/Balon_turkuaz.webp',
            turuncu : 'assets/Parcalar/Balon_turuncu.webp',
            yesil : 'assets/Parcalar/Balon_yesil.webp',
        },
        FinalScreen : {
            Tebrikler_Buton : 'assets/Tebrikler/Tebrikler_Buton.webp',
            Tebrikler : 'assets/Tebrikler/Tebrikler.webp',
        },
        ToplamaCarpma : {
            Toplama_yesil : 'assets/Parcalar/Toplama_yesil.webp',
            Toplama_tozpembe : 'assets/Parcalar/Toplama_tozpembe.webp',
            Toplama_oyunu_buton : 'assets/Parcalar/Toplama_oyunu_buton.webp',
            Toplama_oyunu_Baslik : 'assets/Parcalar/Toplama_oyunu_Baslik.webp',
            Toplama_oyunu : 'assets/Parcalar/Toplama_oyunu.webp',
            Toplama_oyun_basligi : 'assets/Parcalar/Toplama_oyun_basligi.webp',
            Toplama_mavi : 'assets/Parcalar/Toplama_mavi.webp',
            Profil2_buton : 'assets/Parcalar/Profil2_buton.webp',
            Profil_buton : 'assets/Parcalar/Profil_buton.webp',
            Islem_paneli : 'assets/Parcalar/Islem_paneli.webp',
            Carpma_sari : 'assets/Parcalar/Carpma_sari.webp',
            Carpma_oyun_baslik : 'assets/Parcalar/Carpma_oyun_baslik.webp',
            Carpma_mor : 'assets/Parcalar/Carpma_mor.webp',
            Carpma_buzmavi : 'assets/Parcalar/Carpma_buzmavi.webp',
            Carpim_oyunu_buton : 'assets/Parcalar/Carpim_oyunu_buton.webp',
            Carpim_oyunu_baslik : 'assets/Parcalar/Carpim_oyunu_baslik.webp',
            Carpim_oyunu : 'assets/Parcalar/Carpim_oyunu.webp',
            Ayarlar_buton : 'assets/Parcalar/Ayarlar_buton.webp',
        }
    }; 
    createImgeButton(x, y, url, action, config = {}) {
    const {
        text = "",
        textColor = '#000000',
        fontSize = '36px',
        fontFamily = 'TemelYazi',
        scale = 1,
        textOrigin = { x: 0.5, y: 0.5 },
        btnOrigin = { x: 0.5, y: 0.5 }
    } = config;

    const container = this.scene.add.container(x, y);
    
    const btn = this.scene.add.image(0, 0, url).setScale(scale).setOrigin(btnOrigin.x, btnOrigin.y);
    const buttonText = this.scene.add.text(0, 0, text, {
        color: textColor,
        fontSize: fontSize,
        fontFamily: fontFamily,
    }).setPadding(10).setOrigin(textOrigin.x, textOrigin.y);

    container.add([btn, buttonText]);
    container.setSize(btn.displayWidth, btn.displayHeight);
    
    container.setInteractive(
        new Phaser.Geom.Rectangle(
            0,
            0,
            container.width,
            container.height
        ),
        Phaser.Geom.Rectangle.Contains,
        { useHandCursor: true }
    );

    container.on("pointerdown", () => {
        if (typeof action === "function") {
            action();
        } else if (typeof action === "string") {
            this.scene.scene.start(action);
        }
    });

    return container;
    }
    setBackground(url){//Arka plan ayarlamak için  
        const { width, height } = this.scene.cameras.main;
        const centerX = width / 2;
        const centerY = height / 2;

        this.scene.cameras.main.setBackgroundColor('#E3F2FD');
        const background = this.scene.add.image(centerX, centerY, url).setDisplaySize(width, height);
        return background;
    }
    createHeader(url, label,ses = null,config = {}) {//Üst başlık
        const {
            headerText = 40,
            fontSize = '48px', 
            fill = '#000000',
            fontFamily = 'TemelYazi'
        } = config;
        const { width } = this.scene.cameras.main;
        const headerContainer = this.scene.add.container(width / 2, 80);
        if(ses){
                this.scene.sound.stopByKey(ses);
                this.scene.sound.play(ses);
                this.scene.events.once('shutdown', () => this.scene.sound.stopAll());
            }
        const bgImage = this.scene.add.image(0, 0, url);

        const textY = bgImage.height - headerText;
        
        const yazi = this.scene.add.text(0, textY, label, { 
            fill: fill,
            fontSize: fontSize, 
            fontFamily: fontFamily
        }).setOrigin(0.5);

        const iconX = -(yazi.displayWidth / 2) - 50; 

        if(label){
            const header2Icon = this.createImgeButton(iconX, textY, 'Ses_buton', () => {
            if(ses){
                this.scene.sound.stopByKey(ses);
                this.scene.sound.play(ses);
            }
        }, { scale: 0.06 });
        headerContainer.add([bgImage, yazi, header2Icon]);
        }
        else
        headerContainer.add([bgImage, yazi]);

        return headerContainer;
    }
    createBottomBar(next, config = {}) {//Alt başlık
        const {
            width = this.scene.cameras.main.width,
            height = this.scene.cameras.main.height,
            bar = 'Kontrol_cubuk',
            button = 'Onceki_sonraki_anamenu_buton',
            btnscale = 0.8,
            stratScene = "Start",
            stratText = "Ana menü",
            back,
            backText = "Önceki",
            nextText = "Sonraki"
        } = config;
        const padding = 20;
        const barContainer = this.scene.add.container(0, height - 40);
        barContainer.setDepth(50);

        const bottomBarBg = this.scene.add.image(width / 2, 0, bar).setScale(2.2, 1).setOrigin(0.5);

        const homeBtn = this.createImgeButton(0, 0, button,stratScene, {
            text : stratText,
            scale: btnscale
        });

        homeBtn.x = (homeBtn.getBounds().width / 2) + padding;

        const nextBtn = this.createImgeButton(0, 0, button,next, {
            text : nextText,
            scale: btnscale
        });
        nextBtn.x = width - (nextBtn.getBounds().width / 2) - padding;

        let backBtn = null;
        if (back != null) {
            backBtn = this.createImgeButton(0, 0, 'Onceki_sonraki_anamenu_buton', back, {
                text :  backText,
                scale: btnscale
            });
            backBtn.x = width - nextBtn.getBounds().width - (backBtn.getBounds().width / 2) - padding;
        }

        barContainer.add(bottomBarBg);
        barContainer.add(homeBtn);
        barContainer.add(nextBtn);
        if(backBtn)barContainer.add(backBtn);

        return barContainer;
    }
    //kayıp olan yazı
    triggerFeedback(Container, label, color, config = {}) {
        const {
            strokeThickness = 4,
            fontFamily= 'TemelYazi',
            fontSize = '40px',
            stroke = '#000',
            duration =1000,
            distance =80
        } = config;
        const feedback = this.scene.add.text(Container.getBounds().right,Container.y, label, { 
            strokeThickness: strokeThickness,
            fontFamily:fontFamily,
            fontSize: fontSize,
            stroke: stroke, 
            fill: color
        }).setOrigin(0.5);
        this.scene.tweens.add({
            targets: feedback,
            y: Container.y - distance,
            alpha: 0,
            duration: duration,
            onComplete: () => feedback.destroy()
        });
    }
    createDraggableImge(x, y,url,label,config = {}) {
        const {
            TextColor = '#000000',
            fontSize = '48px',
            scale = 1
        } = config;
            const container = this.scene.add.container(x, y);

            const card = this.scene.add.image(0,0,url).setScale(scale );
            const text = this.scene.add.text(0, 0, label, { 
                fontFamily : 'TemelYazi',
                fontSize: fontSize, 
                color: TextColor,
            }).setOrigin(0.5);

            container.add([card, text]);
            container.setData({
            'Text' :  text,
            'baslangicX':x,
            'baslangicY': y,
            'rectangle' : card,
            'currentBlock': null
            });
            
            container.setSize(card.width, card.height);
            container.setInteractive({ draggable: true, useHandCursor: true });

            container.on("dragstart", () => {
                this.scene.children.bringToTop(container);
                container.setAlpha(0.8);
            });

            container.on("drag", (pointer, dragX, dragY) => {
                container.x = dragX;
                container.y = dragY;
            });

            container.on("dragend", () => {
                container.setAlpha(1);
            });

            return container;
    }
    //Progress bar oluşturma
    createProgressBar(x, y,config = {}) {
        const {
            barColor = 0xa29fbd,
            textColor = '#385ebd',
            fontSize ='22px' 
        } = config;
        const barBg = this.scene.add.graphics();
        barBg.fillStyle(barColor, 1);
        barBg.fillRoundedRect(x - 200, y, 400, 25, 12);

        const progressBar = this.scene.add.graphics();

        const counterText = this.scene.add.text(x, y - 25, "", { 
            fontSize: fontSize, 
            color: textColor, 
            fontWeight: 'bold' 
        }).setOrigin(0.5);

        // Tüm nesneleri bir paket olarak döndürüyoruz
        return { barBg, progressBar, counterText, x, y };
    }
    //Progress bar güncelleme
    updateProgressBar(uiComponents, currentIndex, totalQuestions) {
        const { progressBar, counterText, x, y } = uiComponents;

        counterText.setText(`${currentIndex + 1} / ${totalQuestions}`);
        
        progressBar.clear();
        progressBar.fillStyle(0x4CAF50, 1);

        const progress = (currentIndex + 1) / totalQuestions;

        if (progress > 0) {
            progressBar.fillRoundedRect(x - 200, y, 400 * progress, 25, 12);
        }
    }
    //bitiş ekranı
    showFinalScreen(correctCount,AllCount,score) {
            const { width, height } = this.scene.cameras.main;

            // Karartma paneli
            const overlay = this.scene.add.rectangle(width/2, height/2, width, height, 0x000000, 0.);
            overlay.setDepth(49);
            
            this.scene.tweens.add({ targets: overlay, fillAlpha: 0.5, duration: 500 });

            const successRate = Math.round((correctCount /AllCount) * 100);

            const finalMainText = this.scene.add.image(width/2,height/4,'Tebrikler').setDepth(49);
            const finalSubText = this.scene.add.text(width/2, height/2, 
                `Toplam Puan: ${score}\nBaşarı Oranı: %${successRate}`, {
                fontSize: '64px', fill: '#fff', align: 'center', fontFamily: 'TemelYazi'
            }).setOrigin(0.5).setDepth(49).setAlpha(0).setPadding(10);

            this.scene.tweens.add({
                targets: [finalMainText, finalSubText],
                alpha: 1,
                y: '-=20',
                duration: 800,
                delay: 500
            });

            const restartBtn = this.createImgeButton(width/2, height/2+150,'Tebrikler_Buton',undefined , {
                text :"YENİDEN DENE",
            }).setDepth(49);
            restartBtn.on('pointerdown', () => {
                this.scene.scene.restart();
            });
            restartBtn.on('pointerover', () => restartBtn.setScale(1.1));
            restartBtn.on('pointerout', () => restartBtn.setScale(1));
    }
    downloadJsonData() {
        const allData = this.scene.registry.getAll();
        
        try {
            const dataString = JSON.stringify(allData, null, 2);
            const blob = new Blob([dataString], { type: 'application/json' });
            const url = window.URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = 'oyun_verisi.json'; // Dosya adı ve uzantısı
            a.click();
            
            // Bellek temizliği (Memory Management)
            window.URL.revokeObjectURL(url);
            console.log("Veri başarıyla indirildi.");
        } catch (error) {
            console.error("Veri dönüştürme hatası:", error);
        }
    }
}