//Button oluşturma
export function createButton(x, y, label, action, config = {}) {
    const {
        ButtonColor = 0xffffff,//Button rengi
        buttonActionColor = 0xdddddd,
        strokeColor = 0x000000,//Çerçeve rengi
        strokeP = 3,
        textColor = '#000000',//Metin rengi
        fontSize = '24px',//font boyutu
        fontFamily = 'Arial',
        fontWeight = 'bold',
        padding = 20
    } = config;

    const container = currentScene.add.container(x, y);
    const buttonText = currentScene.add.text(0, 0, label, {
        fontSize: fontSize,
        color: textColor,
        fontFamily: fontFamily,
        fontWeight: fontWeight
    }).setOrigin(0.5);

    const bgWidth = buttonText.width + padding;
    const bgHeight = buttonText.height + padding;

    const bg = currentScene.add.rectangle(
        0, 0, 
        bgWidth, 
        bgHeight, 
        ButtonColor
    );
    bg.setStrokeStyle(strokeP, strokeColor);

    container.add([bg, buttonText]);
    container.setDepth(10);

    container.setInteractive(
        new Phaser.Geom.Rectangle(-bgWidth / 2, -bgHeight / 2, bgWidth, bgHeight),
        Phaser.Geom.Rectangle.Contains
    );
    container.useHandCursor = true;

    container.on("pointerdown", () => {
        bg.setFillStyle(buttonActionColor); // Tıklama efekti 
        if (typeof action === "function") {
            action();
        } else if (typeof action === "string") {
            currentScene.scene.start(action);
        }
    });
    const resetStyle = () => bg.setFillStyle(ButtonColor);
    container.on("pointerup", resetStyle);
    container.on("pointerout", resetStyle);

    return container;
}
//Üst başlık
export function createHeader(config = {}) {
    const { 
        text = "deneme", 
        height = 60,
        width = currentScene.cameras.main.width,
        bgColor = 0x00ACC1,
        barColor= 0x000000,
        textColor = '#ffffff', 
        fontSize = '24px',
        fontWeight = 'bold',
        fontFamily = 'Arial',
        align =  'center',
    } = config;

    const headerBg = currentScene.add.graphics();
    headerBg.fillStyle(bgColor, 1);//arkaplan rengi
    headerBg.fillRect(0, 0, width, height);

    headerBg.lineStyle(3, barColor, 1);
    headerBg.lineBetween(0, height, width, height);

    const headerText = currentScene.add.text(width / 2, height / 2, text, {
        fontSize: fontSize,
        color: textColor,
        fontFamily: fontFamily,
        fontWeight: fontWeight,
        align: align
    }).setOrigin(0.5);

    headerBg.setDepth(50);
    headerText.setDepth(50);

    return { bg: headerBg, text: headerText };
}
//Kaydırılabilir kart oluşturmak için 
export function createDraggableCard(x, y,label,config = {}) {
    const {
        CardColor = 0xaa00ff,
        TextColor = '#000000',
        TextBGColor = '#ffffff00',
        TextStrokeColor = 0x000,
        TextSize = '36px',
        TextPadding = { x: 15, y: 5 },
        padding = 10,
    } = config;
        const container = currentScene.add.container(x, y);

        //yazını oluşturulması için
        const text = currentScene.add.text(0, 0, label, { 
            fontSize: TextSize, 
            color: TextColor,
            backgroundColor: TextBGColor,
            padding: TextPadding
        }).setOrigin(0.5);

        //text alanı 
        const bounds = text.getBounds();
        const card = currentScene.add.rectangle(0, 0, bounds.width + padding, bounds.height + padding, CardColor)
            .setStrokeStyle(2, TextStrokeColor);

        container.add([card, text]);
        container.setData('Text', text);
        container.setData('rectangle', card);
        container.setData('currentBlock', null);
        
        container.setSize(card.width, card.height);
        container.setInteractive({ draggable: true, useHandCursor: true });

        // Sürükleme başladığında
        container.on("dragstart", () => {
            currentScene.children.bringToTop(container); // Kartı en üste getir
            container.setAlpha(0.8);
        });
        container.on("drag", (pointer, dragX, dragY) => {
            container.x = dragX;
            container.y = dragY;
        });
        return container;
}
//Ovalı düğme
export function drawButtonStyle(x,y,label,config =  {}) {//{[button, text]}
    const {
        action = null,
        fillColor = 0xffffff,
        strokeColor = 0x000000,
        textColor  = '#2E7D32',
        fontSize = '24px',
        btnWidth = 250,
        btnHeight = 60
    } = config;
    
        const button = currentScene.add.graphics();
        button.clear();
        button.fillStyle(fillColor, 1);
        button.fillRoundedRect(-btnWidth/2, -btnHeight/2, btnWidth, btnHeight, 30);
        button.lineStyle(4, strokeColor);
        button.strokeRoundedRect(-btnWidth/2, -btnHeight/2, btnWidth, btnHeight, 30);

        const text = currentScene.add.text(0, 0,label, { color: textColor, fontSize: fontSize, fontWeight: 'bold' }).setOrigin(0.5);

        const container = currentScene.add.container(x, y, [button, text]);
        container.setSize(btnWidth, btnHeight).setInteractive({ useHandCursor: true });

        container.setData('btnWidth',btnWidth);
        container.setData('btnHeight',btnHeight);


        container.on("pointerdown", () => {
        if (typeof action === "function") {
            action();
        } else if (typeof action === "string") {
            currentScene.scene.start(action);
        }
        });
        return container;
}