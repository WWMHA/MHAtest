import { Start } from './scenes/Start.js';
import { Yazim } from './scenes/Yazim.js';
import { DogruYanlis } from './scenes/DogruYanlis.js';
import { Balon } from './scenes/Balon.js';
import { Eslestir } from './scenes/Eslestir.js';
import { Elma } from './scenes/Elma.js';
import { Carpim } from './scenes/Carpma.js';
import { Toplama } from './scenes/Toplama.js';
import { CarpimOyunu } from './scenes/CarpimOyunu.js';
import { CarpimOyunu2 } from './scenes/CarpimOyunu2.js';
import { ToplamOyunu } from './scenes/ToplamOyunu.js';
import { ToplamOyunu2 } from './scenes/ToplamOyunu2.js';
import { PreloadScene } from './scenes/PreloadScene.js';
import { GameScene } from './scenes/Test.js';
import { UIPlugin } from './utils/engine.js';
import { SkoolTest } from './scenes/SkoolTest.js';

const config = {
    type: Phaser.AUTO,
    title: 'Overlord Rising',
    description: '',
    parent: 'game-container',
    width: 1920,
    height: 1080,
    backgroundColor: '#000000',
    pixelArt: false,
    scene: [
        PreloadScene,
        Start,
        Yazim,
        DogruYanlis,
        Balon,
        Eslestir,
        Elma,
        Carpim,
        Toplama,
        CarpimOyunu,CarpimOyunu2,
        ToplamOyunu,ToplamOyunu2,
        GameScene,SkoolTest
    ],
    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH
    },
    physics: {
        default: 'arcade', // Fizik motoru burada tanımlanmalı
        arcade: {
            gravity: { y: 0 }, // Uzay temalıysa yerçekimini 0 yapabiliriz
            debug: false
        }
    },
    plugins: {
        scene: [{ key: 'UIPlugin', plugin: UIPlugin, mapping: 'ui' }]
    }
}

new Phaser.Game(config);
            